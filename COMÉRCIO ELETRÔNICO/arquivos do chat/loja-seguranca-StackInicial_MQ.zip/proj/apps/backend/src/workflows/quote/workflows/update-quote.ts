import { createWorkflow, WorkflowResponse } from "@medusajs/framework/workflows-sdk";
import { ModuleQuote, ModuleUpdateQuote } from "../../../types";
import { updateQuotesStep } from "../steps/update-quotes";

/*
  A workflow that updates a quote. 
*/
export const updateQuotesWorkflow = createWorkflow(
  "update-quotes",
  function (input: ModuleUpdateQuote[]): WorkflowResponse<ModuleQuote[]> {
    return new WorkflowResponse(updateQuotesStep(input));
  }
);
